<?php
// Heading
$_['heading_title']    = 'Allcats';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Allcats module!';
$_['text_edit']        = 'Edit Allcats Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify allcats module!';