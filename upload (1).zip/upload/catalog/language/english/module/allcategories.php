<?php

$_['heading_title'] 	= 'All Categories';
$_['description'] 		= 'This page shows all of categories with category images';

?>