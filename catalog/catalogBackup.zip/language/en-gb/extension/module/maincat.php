<?php
// Heading
$_['heading_title'] = '<span>Categorys</span> List';