<?php
class ControllerProductModels extends Controller {
	public function index() {
        $this->load->model('catalog/product');
        $this->load->model('catalog/filter');
        $category_id = $this->request->post['category_id'];
        $manufacturer_id  = $this->request->post['manufacturer_id'];
        $json = array();
        
        $filter_groups = $this->model_catalog_filter->getAllFilters();
        if ($filter_groups) {
            foreach ($filter_groups as $filter_group) {
                $childen_data = array();

                foreach ($filter_group['filter'] as $filter) {
                    $filter_data = array(
                        'filter_category_id' => $category_id,
                        'filter_filter'      => $filter['filter_id'],
                        'filter_manufacturer_id'    => $manufacturer_id 
                    );

                    $childen_data[] = array(
                        'filter_id' => $filter['filter_id'],
                        'name'      => $filter['name'] . ($this->config->get('config_product_count') ? ' (' . $this->model_catalog_product->getTotalProducts($filter_data) . ')' : '')
                    );
                }

                $json[] = array(
                    'filter_group_id' => $filter_group['filter_group_id'],
                    'name'            => $filter_group['name'],
                    'filter'          => $childen_data
                );
            }
        }


        //$this->response->setOutput($this->load->view('product/models', $data));
$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}